setwd('/Users/liyixian1990/Desktop/NP')
library(sinkr)
library(vegan)
set.seed(1)
gen<-read.csv('v6div.csv',header=T,row.names=1)
env<-read.csv('v41hel.csv',header=T,row.names=1)


bvstep1<- bvStep(wisconsin(gen), wisconsin(env), 
                 fix.dist.method="jaccard", var.dist.method="euclidean",#这里的距离和vegdist一样，环境距离用euclidean，遗传距离用jaccard
                 scale.fix=FALSE, scale.var=FALSE, 
                 max.rho=0.95, min.delta.rho=0.001,
                 random.selection=TRUE,
                 prop.selected.var=0.3,
                 num.restarts=50,
                 output.best=10,
                 var.always.include=NULL)
bvstep1

bvstep1$order.by.best
bvstep1$order.by.i.comb
bvstep1$best.model.vars
bvstep1$best.model.rho
bvstep1$var.always.include
bvstep1$var.exclude

set.seed(1)
bvstep2<- bvStep(wisconsin(gen), wisconsin(env), 
                 fix.dist.method="jaccard", var.dist.method="euclidean",
                 scale.fix=FALSE, scale.var=FALSE, 
                 max.rho=0.95, min.delta.rho=0.001,
                 random.selection=TRUE,
                 prop.selected.var=0.3,
                 num.restarts=50,
                 output.best=10,
                 var.always.include=c(2,8,39))#这里加上了哪几个需要看上一步那个结果，哪几个一直出现就加哪几个，这里是表观那几个
bvstep2$best.model.vars
bvstep2