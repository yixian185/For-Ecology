setwd('/Users/liyixian1990/Desktop/test2')
dat <- read.csv('f00.csv', row.names = 1)#基因数据，自己的数据可以t一下

dat<-t(dat)
#dat_scale <- as.matrix(log2(dat))#数据进行转换，他这里是避免基因的表达差异太大，进行一个对数转换，当然可以进行其他的转换,01数据就不用转换了

library(kohonen)
som_grid <- somgrid(xdim = 10, ydim = 10, topo = 'hexagonal')  #这里也可以选rectangular

set.seed(100)
som_model <- supersom(dat, grid = som_grid, rlen = 10000)#这个rlen应该在10000左右，最终的要求是要在一个小的值附近稳定，可以从100开始试

plot(som_model, type = 'changes')#这个值最后平稳就行
plot(som_model, type = 'count')
plot(som_model, type = 'dist.neighbours')
plot(som_model, type = 'codes')

coolBlueHotRed <- function(n, alpha = 0.7) rainbow(n, end=4/6, alpha=alpha)[n:1]

color_by <- apply(som_model$data[[1]], 1, mean)
unit_colors <- aggregate(color_by, by = list(som_model$unit.classif), FUN = mean, simplify = TRUE)
unit_dat <- data.frame(value = rep(0, 100))
unit_dat[unit_colors$Group.1,'value'] <- unit_colors$x

plot(som_model, type = 'property', property = unit_dat[[1]], palette.name = coolBlueHotRed, 
     shape = 'round', keepMargins = TRUE, border = NA)

plot(som_model, type = 'property', property = unit_dat[[1]], palette.name = coolBlueHotRed, 
     shape = 'straight', keepMargins = TRUE, border = NA)

som_model$grid

som_model_class <- data.frame(gene_name = rownames(som_model$data[[1]]), code_class = som_model$unit.classif)
som_model_class <- cbind(som_model_class, dat)
head(som_model_class) 
som_model$grid#这个是每个点的坐标，由于自己用的六边形，所以坐标有小数点，换成rectangular应该就没问题了

som.hc <- cutree(hclust(object.distances(
  som_model, "codes")), 2)
#plot(som_model)
add.cluster.boundaries(som_model, som.hc)#加黑线分组

dev.off()
rm(list=ls())