
setwd('/Users/liyixian1990/Desktop/test2')

library(vegan)
library(ggplot2)

cera_table <- read.csv('cge.csv', header = T,row.names=1)
cera_matrix <- cera_table

envdat_raw <- read.csv('c4.csv', header = T, row.names = 1)#这里从mantel那个图里选出来4个相关因素
h.envdat_raw<-decostand(envdat_raw,method='hellinger')
envdat <- h.envdat_raw[match(row.names(cera_matrix), row.names(envdat_raw)),]


decorana(cera_matrix)

res <- rda(cera_matrix ~ ., envdat)

res
plot(res)

xxxx <- summary(res)
aa <- xxxx$concont$importance
aa <- round(aa, 4)

aa

library(dplyr)
clu<-read.csv('ccluster.csv')


pdat <- res$CCA
samples<-data.frame(sample = row.names(pdat$u),RDA1 = pdat$u[,1],RDA2 = pdat$u[,2],cluster=clu$cluster)
species<-data.frame(spece = row.names(pdat$v),RDA1 = pdat$v[,1],RDA2 = pdat$v[,2])
envi<-data.frame(en = row.names(pdat$biplot),RDA1 = pdat$biplot[,1],RDA2 = pdat$biplot[,2])


library(ggrepel)
p <- ggplot() + 
  geom_hline(aes(yintercept = 0), colour="gray88", linetype="dashed") + 
  geom_vline(aes(xintercept = 0), colour="gray88", linetype="dashed")  +

  geom_segment(data = species,aes(x=0, xend= RDA1, y=0, yend= RDA2 ), arrow = arrow(length = unit(0.3, "cm")), colour = 'navy',size=1) +
  geom_text(data = species,aes(x = RDA1*1.1, y = RDA2*1.1, label = spece), size = 3, colour = 'navy') +

  geom_segment(data = envi,aes(x=0, xend= RDA1, y=0, yend= RDA2 ), arrow = arrow(length = unit(0.3, "cm")), colour = 'brown',size=1) +
  geom_text(data = envi,aes(x = RDA1*1.1, y = RDA2*1.1, label = en), size = 3, colour = 'brown', check_overlap = F) +
  geom_point(data = samples, aes(x=RDA1, y=RDA2,color=factor(cluster)),size = 6)+

  geom_text_repel(data = samples,aes(x = RDA1*1.1, y = RDA2*1.1, label = sample),size = 3, colour = 'black')+
  theme_bw() +
  theme(panel.grid.major=element_line(color=NA), panel.grid.minor = element_blank(),
        panel.border = element_rect(color='black',size=1.5))+
        

  xlab(paste('RDA1 (', aa[2,1]*100, '%)', sep ='')) + ylab(paste('RDA2 (', aa[2,2]*100, '%)', sep ='')) +
  theme(text=element_text(family='Arial',face='bold',size=18))+
  theme(axis.text.x=element_text(vjust=1,size=15,face = "bold",color='black'))+
  theme(axis.text.y=element_text(vjust=1,size=15,face = "bold",color='black'))
  #stat_ellipse(aes(clu2$RDA1,clu2$RDA2,color=clu2$cluster,group=clu2$cluster ),size = 1,level = 0.6,linetype='dashed',show.legend = F)

print(p)
dev.off()

anova(res, by = "term", permutations=999)#看显著性P值
