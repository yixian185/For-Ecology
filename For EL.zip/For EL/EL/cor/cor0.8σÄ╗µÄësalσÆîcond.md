setwd('/Users/liyixian1990/Desktop/cor')
library(dplyr)
library(corrr)
library(ggsci)
library(viridis)
library(RColorBrewer)
t<-read.csv('v19final.csv',header = T,row.names=1)#可以是遗传数据，可以是全部遗传环境数据
t%>%
  correlate()%>%
  network_plot(min_cor = 0.8,colours=c("salmon", "grey", "seagreen"),repel=T)#这里可以调整min_cor=0.2