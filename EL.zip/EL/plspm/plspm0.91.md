setwd('/Users/liyixian1990/Desktop/test2')
library(plspm)

pls <- read.csv('h.csv',row.names=1)
#library(vegan)
#library(dplyr)
#a<-decostand(pls,method = 'hellinger')
#write.csv(a,'h.csv')
pls_blocks <- list(
  Tem = c('WT'), 
  TDS=c('TDS','Sal'),
  Chl=c('Chla'),
  GenDiv = c(	'He'),
  EpiVar = c('eHe'))

Tem <- c(0, 0, 0, 0,0)
TDS <- c(1, 0, 0,0,0)
Chl<-c(1,0,0,0,0)
GenDiv <- c(1, 1, 1,0,0)
EpiVar<-c(1,1,1,1,0)

pls_path <- rbind( Tem,TDS,Chl,GenDiv,EpiVar)
colnames(pls_path) <- rownames(pls_path)

pls_modes <- rep('A', 5)


pls_pls <- plspm(pls, pls_path, pls_blocks, modes = pls_modes,boot.val = T, br=1000)

summary(pls_pls)
pls_pls$gof#这个系数在0.718左右，大于0.7就可行

paths<-pls_pls$path_coefs
arrow_lwd = 10*round(paths, 2)
arrow_lwd2=abs(arrow_lwd)#这一步提取相关系数，取两位数，然后取绝对值，不然负数不显示

innerplot(pls_pls, colpos = 'lightcoral', colneg = 'lightblue', 
          cex=1,txt.xadj=0.5,txt.yadj=0.5,show.values = T, 
          lcol = 'black',txt.col = 'black' , box.cex = 1,
          box.prop = 0.3,box.size = 0.05,box.lwd = 1,cex.txt = 0.8,
          arr.pos=0.8,arr.lwd = arrow_lwd2)

#下边的相关性，用于模型调整，一般大于0.7才行

outerplot(pls_pls, what = 'loadings', arr.width = 0.1, colpos = 'lightcoral', 
          colneg = 'darkseagreen2', show.values = TRUE, lcol = 'black',box.size=0.05)
outerplot(pls_pls, what = 'weights', arr.width = 0.1, colpos = 'lightcoral', 
          colneg = 'darkseagreen2', show.values = TRUE, lcol = 'black',
          box.prop = 0.3,box.size = 0.04,box.lwd = 1,cex.txt = 0.8)      
dev.off()
rm(list=ls())