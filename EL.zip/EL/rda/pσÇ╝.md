> anova(res, by = "term", permutations=999)#看显著性P值
Permutation test for rda under reduced model
Terms added sequentially (first to last)
Permutation: free
Number of permutations: 999

Model: rda(formula = cera_matrix ~ WT + TDS + Sal + Chl.a, data = envdat)
         Df  Variance      F Pr(>F)
WT        1 0.0016925 1.5249  0.256
TDS       1 0.0027758 2.5009  0.127
Sal       1 0.0002736 0.2465  0.832
Chl.a     1 0.0004947 0.4457  0.710
Residual  4 0.0044397          