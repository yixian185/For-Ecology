setwd('/Users/liyixian1990/Desktop/EL')#存6*15
library(ggtree)
library(ggplot2)

library(treeio)#用这个，popgene那个树用mega打开，另存为nwk，其实就是一些括号
tree<-read.newick('v.nwk')

ggtree(tree) + 
  geom_tippoint(size = 2) +
  geom_tiplab(hjust = -0.1) +
  theme_tree2()

library(ape)
tree <-as.phylo(tree)

group <- read.csv('vgroup.csv', row.names = 1,sep=',')#分组用group12时，没出现group是0的情况
group <- split(row.names(group), group$groups)
library(ggplot2)
p <- ggtree(groupOTU(tree, group), aes(color = group), size = 1) + 
  geom_tippoint(size = 2, show.legend = FALSE) +
  geom_tiplab(hjust = -0.2, show.legend = FALSE) + 
  theme_tree2() + 
  xlim_tree(0.1)+
  theme(text=element_text(family='Arial',face='bold',size=17))+
  scale_color_manual(values=c('#00A087FF','#BC3C29FF','#6F99ADFF'))
p

msp<- read.csv('vms.csv', row.names = 1)

msp$type <- factor(rownames(msp), levels = rev(rownames(msp)))
msp <- reshape2::melt(msp, id = 'type')
msp <- msp[c(1, 3, 2)]

head(msp)

p2 <- p + 
  geom_facet(panel = 'Methylation Relative', data = msp, geom = geom_bar, 
             mapping = aes(x = 100*value, fill = variable), color = 'gray30', 
             orientation = 'y', width = 0.8, stat = 'identity') + 
  scale_fill_manual(values = c('#F39B7FFF', '#8491B4FF', '#91D1C2FF', '#B09C85FF')) 
facet_widths(p2, widths = c(1.2, 1.7))