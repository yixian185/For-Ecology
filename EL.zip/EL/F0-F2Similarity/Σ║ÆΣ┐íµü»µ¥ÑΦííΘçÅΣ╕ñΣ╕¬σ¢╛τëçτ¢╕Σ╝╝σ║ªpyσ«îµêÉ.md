```
import cv2
import numpy as np
import sklearn.metrics as skm
img1 = cv2.imread('f00nocut.jpg', cv2.IMREAD_GRAYSCALE)
img2 = cv2.imread('f22nocut.jpg', cv2.IMREAD_GRAYSCALE)
x = np.reshape(img1, -1)
y = np.reshape(img2, -1)
def hxx_forward(x, y):
    return skm.mutual_info_score(x, y)
def hxx(x, y):
    size = x.shape[-1]
    px = np.histogram(x, 256, (0, 255))[0] / size
    py = np.histogram(y, 256, (0, 255))[0] / size
    hx = - np.sum(px * np.log(px + 1e-8))
    hy = - np.sum(py * np.log(py + 1e-8))

    hxy = np.histogram2d(x, y, 256, [[0, 255], [0, 255]])[0]
    hxy /= (1.0 * size)
    hxy = - np.sum(hxy * np.log(hxy + 1e-8))

    r = hx + hy - hxy
    return r
print(hxx_forward(x, y))
print(hxx(x, y))
```