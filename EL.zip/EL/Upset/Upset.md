setwd('/Users/liyixian1990/Desktop/test2')
library(vegan)
library(rdacca.hp)
library(UpSetVP)
gen<-read.csv('vgen.csv',row.names=1)
env<-read.csv('v4.csv',row.names=1)

mod <- rdacca.hp(gen,env,method = 'RDA', var.part = TRUE, type = 'adjR2', scale = FALSE)#这里环境数据必须精简到和遗传参数差不多的数量，不然出不来结果

upset_vp(mod, plot.hp = TRUE, order.part = 'effect', nVar = 40)
upset_vp(mod, plot.hp = TRUE, order.part = 'degree', nVar = 40)

barplot_hp(mod, col.fill = 'var', 
           col.color = c('#BC3C29FF', '#20854EFF', '#FFDC91FF', '#0072B5FF'))#这里有4个响应变量,最后组合的时候在PDF里编辑时，把颜色条复制过来就行

dev.off()