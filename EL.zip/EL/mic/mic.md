setwd('/Users/liyixian1990/Desktop/mic')
library(minerva) 
library(ggplot2)
library(reshape2)

vdiv<- read.csv("v6.csv",header=T,row.names=1)
venv<-read.csv("v41hel.csv",header=T,row.names=1)

vdiv<-t(vdiv)

vdiv <- vdiv[rowSums(vdiv)>0,]

mat1 <- match(rownames(venv),colnames(vdiv))
vdiv <- vdiv[,mat1]

mat2 <- match(colnames(vdiv),rownames(venv))
venv <- venv[mat2,]

mic <- c()
for (i in 1:nrow(vdiv)){  
  res = c()
  for (j in 1:ncol(venv)){ 
    res = c(res,mine(as.numeric(vdiv[i,]),venv[,j])$MIC)
  }
  mic = rbind(mic,res)
}

colnames(mic) <- colnames(venv)
rownames(mic) <- rownames(vdiv)
head(mic)

per <-c()
for (k in 1:ncol(mic)){ # k = 1
  per = cbind(per,table(mic[,k]>0.4)[2]*100/nrow(mic))#0.4代表显著相关
}

colnames(per)<-colnames(venv)
rownames(per)<-"percent"

per.gg<-melt(per,
             id.vars = c("percent"),
             measure.vars = colnames(per),
             variable.name='venv',
             value.name='Percentage')
per.gg
p<-ggplot(per.gg)+
  geom_bar(aes(x=Var2,y=Percentage),stat="identity")+#这里per.gg用的是percentage
  coord_flip()+labs(title="vgen (MIC>0.4)",x="Factors",y="Percentage")+
  theme_bw()
p

dev.off()
rm(list=ls())