setwd('/Users/liyixian1990/Desktop/test2')

library(ggplot2)
library(viridis)
library(ggridges)
library(RColorBrewer)
a<-read.csv('ff0.csv')
ggplot(a,aes(x=Value, y=Type,
             fill = stat(x)))+
  geom_density_ridges_gradient(
    scale=1.5, 
    rel_min_height=0.01, 
    gradient_lwd =.6)+
  scale_x_continuous(expand = c(0.01, 0))+
  scale_y_discrete(expand = c(0.01,0))+
  #scale_fill_viridis(name="scale", option = "E")+
  labs(
    title="title",
    subtitle="subtitle")+
  theme_ridges(font_size = 13, grid = TRUE)+
  scale_fill_gradientn(colours=paletteer_c("scico::bamako", n = 13))+
  #scale_fill_gradientn(colours = colorRampPalette(rev(brewer.pal(5,'Greens')))(8))+
  theme_classic()
dev.off()