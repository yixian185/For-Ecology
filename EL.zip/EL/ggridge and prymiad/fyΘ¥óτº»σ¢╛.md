rm(list=ls())
dev.off()
setwd('/Users/liyixian1990/Desktop/test2')
library(tidyverse)
library(export)
test1 <- read.csv("fp.csv",header = T,sep=",") %>% 
  as_tibble()

test1 %>% 
  mutate(pop = if_else(gender=="gen",-1*pop,pop),
         tem = forcats::fct_inorder(tem),
         tem_x = rep(seq(16.93, 18.68,0.02),2))%>%#间隔不能有重叠
  ggplot(aes(x= tem_x, y = pop,fill = gender))+

  geom_area(stat = "identity", position = "identity",
            color="black",size=0.25) +
  scale_fill_manual(values=c("forestgreen","burlywood"))+
  scale_y_continuous(labels = abs, limits = c(-1, 1), #这里数值在0.5以内
                     breaks = seq(-1, 1, 0.1)) +#间隔0.1,纵坐标的问题
  scale_x_continuous(breaks = seq(16.93, 18.68, 0.02),#从小到大，间隔是0.02
                     labels=test1$tem[seq(1,nrow(test1)/2,1)])+#test1有15个个体
  theme_classic()+
  theme(panel.grid.minor=element_blank(),
        axis.title=element_text(size=11,color="black"),
        axis.text = element_text(size=10,color="black"),
        legend.title=element_text(size=11,color="black"),
        legend.text=element_text(size=10,color="black"),
        legend.background=element_blank(),
        legend.position = c(0.9,0.88))