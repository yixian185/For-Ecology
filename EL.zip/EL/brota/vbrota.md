rm(list=ls())
dev.off()
setwd('/Users/liyixian1990/Desktop/test2')
a<-read.csv('v41eppl.csv',row.names=1)
library(Boruta)
set.seed(100)
boruta_output <- Boruta(ePPL ~ ., data=na.omit(a), pValue = 0.05, mcAdj = TRUE, doTrace = 2)
summary(boruta_output)
importance <- boruta_output$ImpHistory  

plot(boruta_output, las = 2, xlab = '', main = 'Variable Importance',family = "serif")
boruta_df <- attStats(boruta_output)
boruta_df